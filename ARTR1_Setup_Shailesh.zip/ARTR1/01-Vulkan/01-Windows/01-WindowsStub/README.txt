--- All of this is included in base code for 11-BaseCode ---

1. Window with WM_DESTROY
2. Centering of window
3. Icon
4. Fullscreen
5. Active / Inactive window
6. Gameloop
7. File IO
8. Keypress handling
   a. VK_ESCAPE handling in WM_KEYDOWN.
   b. Handling for key 'F' or 'f' in WM_CHAR.

------------------------------------------------------------